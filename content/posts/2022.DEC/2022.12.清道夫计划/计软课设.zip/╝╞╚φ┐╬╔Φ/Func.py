



class Books(object):
    # 学生信息类
    def __init__(self):
        self.book_ID = ""
        self.book_name=""
        self.book_type = ""
        self.book_author = ""
        self.book_press = ""
        self.price = 0
        self.number = 0
        self.sale=0


def creat_Books(stu,book_ID,book_name,book_type,book_author,book_press,price,number,n=1):
    while n > 0:
        oneStu = Books()
        oneStu.book_ID = book_ID
        print(oneStu.book_ID)
        if oneStu.book_ID == '0':  # 学号为0停止输入
            break
        else:
            for i in range(0, len(stu)):
                if equal(oneStu,stu[i]):
                    return False
        oneStu.book_name = book_name
        oneStu.book_type = book_type
        oneStu.book_author = book_author
        oneStu.book_press = book_press
        oneStu.price = float(price)
        oneStu.number = int(number)
        stu.append(oneStu)
        print("-" * 30)
        n = n - 1
    return True


def equal(s1, s2):
    if s1.book_ID==s2.book_ID:
            return True
    return False


def sale(stu,book_ID,number,ZK):

    for i in range(len(stu)):
        if stu[i].book_ID==book_ID and stu[i].number >=number:
            stu[i].number-=number
            stu[i].sale+=stu[i].price*number*(ZK/10.0)
            return stu[i].price*number*(ZK/10.0)
    return False


def Count_press(stu):
    coun={"小说":0,"文艺":0,"动漫":0,
          "童书":0,"教育":0,"人文社科":0,
          "经管":0,"励志":0,"生活":0,"科技":0}
    for i in stu:
        if i.book_type in coun.keys():
            coun[i.book_type]+=int(i.sale)
    return coun
def Count_sale(stu):
    sum=0
    for i in stu:
        sum+=i.sale
    return sum


def chick(stu,note,choice=1):

    new_list=[]
    print(stu,note,choice)
    for i in stu:
        if choice == 1 and i.book_ID==note:
            new_list.append(i)
        if choice == 2 and i.book_name == note:
            new_list.append(i)
        if choice == 3 and i.book_type == note:
            new_list.append(i)
        if choice == 4 and i.book_author == note:
            new_list.append(i)
        if choice == 5 and i.book_press == note:
            new_list.append(i)

    return new_list
