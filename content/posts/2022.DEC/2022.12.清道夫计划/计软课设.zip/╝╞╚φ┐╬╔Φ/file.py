import pickle

from Func import Books


def Load_file():
    stu_list = []
    with open("Book.txt", 'rb') as dictfile:
        while (1):
            try:
                oneStu = Student()

                readdict = pickle.load(dictfile)
                oneStu.book_ID = readdict["book_ID"]
                oneStu.book_name = readdict["book_name"]
                oneStu.book_type = readdict["book_type"]
                oneStu.book_author = readdict["book_author"]
                oneStu.book_press = readdict["book_press"]
                oneStu.price = readdict["price"]
                oneStu.number = readdict["number"]
                oneStu.sale = readdict["sale"]

                stu_list.append(oneStu)
            except:
                return stu_list
                dictfile.close()



def write_file(stu_list):


    with open("Book.txt", 'wb') as dictfile:
        for stu in stu_list:
            temp = ({"book_ID": stu.book_ID,"book_name": stu.book_name, "book_type": stu.book_type, "book_author": stu.book_author,
                     "book_press": stu.book_press,"price": stu.price,"number": stu.number,"sale": stu.sale})
            pickle.dump(temp, dictfile)
    dictfile.close()
