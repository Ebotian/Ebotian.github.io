

import sys
import Func
from PyQt5.QtWidgets import *
from Face.FMAIN import Ui_MAIN
from Face.FFUNC import Ui_FUNC
from Face.ADD import Ui_ADD
from Face.SALE import Ui_SALE
from Face.Count import Ui_Count
from Face.FIND import Ui_FIND
import file

class SubDialog(QDialog, Ui_MAIN):
    def __init__(self):
        super(SubDialog, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("登录窗口")
        self.pushButton.clicked.connect(self.show_menue_pane)
        self.pushButton_2.clicked.connect(self.close)

    def show_menue_pane(self):  # 调用其他自定义消息框

        user_name=self.lineEdit_2.text()
        user_password=self.lineEdit.text()
        print(user_name)
        print(user_password)

        if user_name=='admin' and user_password=="123456":
            self.newDialog = User_main()
            self.hide()
            self.newDialog.show()

    def close(self):
        sys.exit(app.exec_())

class User_main(QDialog, Ui_FUNC):
    def __init__(self):
        super(User_main, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("主界面")

        self.pushButton.clicked.connect(self.add_book)
        self.pushButton_2.clicked.connect(self.sale_book)
        self.pushButton_3.clicked.connect(self.sale_count)
        self.pushButton_4.clicked.connect(self.find)


    def add_book(self):
        self.newDialog = BOOK_ADD()
        self.newDialog.show()

    def sale_book(self):
        self.newDialog = BOOK_SALE()
        self.newDialog.show()

    def sale_count(self):
        self.newDialog = BOOK_COUNT()
        self.newDialog.show()

    def find(self):
        self.newDialog = BOOK_FIND()
        self.newDialog.show()

## 添加图书
class BOOK_ADD(QDialog, Ui_ADD):
    def __init__(self):
        super(BOOK_ADD, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("主界面")
        self.pushButton.clicked.connect(self.add_book)
        self.pushButton_2.clicked.connect(self.back)

    def add_book(self):
        book_ID=self.lineEdit.text()
        book_name=self.lineEdit_2.text()
        book_type=self.lineEdit_3.text()
        book_author=self.lineEdit_4.text()
        book_press=self.lineEdit_5.text()
        price=self.lineEdit_6.text()
        number=self.lineEdit_7.text()
        print(stu,book_ID,book_name,book_type,book_author,book_press,price,number)
        Func.creat_Books(stu,book_ID,book_name,book_type,book_author,book_press,price,number)

    def back(self):
        file.write_file(stu)
        self.hide()


## 销售图书
class BOOK_SALE(QDialog, Ui_SALE):
    def __init__(self):
        super(BOOK_SALE, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("主界面")
        self.pushButton.clicked.connect(self.sale_book)
        self.pushButton_2.clicked.connect(self.back)


    def sale_book(self):
        book_ID = self.lineEdit.text()
        num = int(self.lineEdit_7.text())
        ZK = int(self.lineEdit_8.text())

        ret=Func.sale(stu,book_ID,num,ZK)
        if ret:
            self.textEdit.setText("出售成功 \n 共消费{%.2f}元"%(ret))
        else:
            self.textEdit.setText("销售失败")
    def back(self):
        file.write_file(stu)
        self.hide()



## 查询图书
class BOOK_FIND(QDialog, Ui_FIND):
    def __init__(self):
        super(BOOK_FIND, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("主界面")
        self.pushButton.clicked.connect(self.FIND_book)
        self.pushButton_2.clicked.connect(self.back)


    def FIND_book(self):
        redio_1 = self.radioButton.isChecked()
        redio_2 = self.radioButton_2.isChecked()
        redio_3 = self.radioButton_3.isChecked()
        redio_4 = self.radioButton_4.isChecked()
        redio_5 = self.radioButton_5.isChecked()
        text = self.lineEdit.text()
        if redio_1:
            ret = Func.chick(stu, text, 1)
            text = ""
            for i in ret:
                text += " 图书条形码   ：{}\n".format(i.book_ID)
                text += " 图书名称     ：{}\n".format(i.book_name)
                text += " 图书类别     ：{}\n".format(i.book_type)
                text += " 图书作者     ：{}\n".format(i.book_author)
                text += " 图书出版社   ：{}\n".format(i.book_press)
                text += " 图书价格     ：{}\n".format(i.price)
                text += " 图书数量     ：{}\n".format(i.number)
                text+="\n\n"
            self.textEdit.setText(text)
        if redio_2:
            ret=Func.chick(stu,text,2)
            text =""
            for i in ret:
                text += " 图书条形码   ：{}\n".format(i.book_ID)
                text += " 图书名称     ：{}\n".format(i.book_name)
                text += " 图书类别     ：{}\n".format(i.book_type)
                text += " 图书作者     ：{}\n".format(i.book_author)
                text += " 图书出版社   ：{}\n".format(i.book_press)
                text += " 图书价格     ：{}\n".format(i.price)
                text += " 图书数量     ：{}\n".format(i.number)
                text += "\n\n"
            self.textEdit.setText(text)
        if redio_3:
            ret = Func.chick(stu, text, 3)
            text = ""
            for i in ret:
                text += " 图书条形码   ：{}\n".format(i.book_ID)
                text += " 图书名称     ：{}\n".format(i.book_name)
                text += " 图书类别     ：{}\n".format(i.book_type)
                text += " 图书作者     ：{}\n".format(i.book_author)
                text += " 图书出版社   ：{}\n".format(i.book_press)
                text += " 图书价格     ：{}\n".format(i.price)
                text += " 图书数量     ：{}\n".format(i.number)
                text += "\n\n"
            self.textEdit.setText(text)
        if redio_4:
            ret = Func.chick(stu, text, 4)
            text = ""
            for i in ret:
                text += " 图书条形码   ：{}\n".format(i.book_ID)
                text += " 图书名称     ：{}\n".format(i.book_name)
                text += " 图书类别     ：{}\n".format(i.book_type)
                text += " 图书作者     ：{}\n".format(i.book_author)
                text += " 图书出版社   ：{}\n".format(i.book_press)
                text += " 图书价格     ：{}\n".format(i.price)
                text += " 图书数量     ：{}\n".format(i.number)
                text += "\n\n"
            self.textEdit.setText(text)
        if redio_5:
            ret = Func.chick(stu, text, 5)
            text = ""
            for i in ret:
                text += " 图书条形码   ：{}\n".format(i.book_ID)
                text += " 图书名称     ：{}\n".format(i.book_name)
                text += " 图书类别     ：{}\n".format(i.book_type)
                text += " 图书作者     ：{}\n".format(i.book_author)
                text += " 图书出版社   ：{}\n".format(i.book_press)
                text += " 图书价格     ：{}\n".format(i.price)
                text += " 图书数量     ：{}\n".format(i.number)
                text += "\n\n"
            self.textEdit.setText(text)

    def back(self):
        self.hide()

## 销售统计
class BOOK_COUNT(QDialog, Ui_Count):
    def __init__(self):
        super(BOOK_COUNT, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("主界面")
        self.pushButton.clicked.connect(self.CUNT_1)
        self.pushButton_2.clicked.connect(self.COUNT_2)
        self.pushButton_3.clicked.connect(self.back)


    def CUNT_1(self):
        PO=Func.Count_press(stu)
        text=""
        for i in PO.keys():
            text+=i+"类 --->销售 "+str(PO[i])+"元 \n"
        self.textEdit.setText(text)

    def COUNT_2(self):
        PO = Func.Count_sale(stu)
        text="销售总金额为 :{%.2f}元"%(PO)
        self.textEdit.setText(text)

    def back(self):
        self.hide()


if __name__ == "__main__":
    #  下面为驱动界面
    stu=file.Load_file()

    app = QApplication(sys.argv)
    Login = SubDialog()
    Login.show()
    sys.exit(app.exec_())
